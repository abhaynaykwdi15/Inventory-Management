"""Pydantic API schemas."""
