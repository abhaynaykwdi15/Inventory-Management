"""Parameterized MySQL database access."""
