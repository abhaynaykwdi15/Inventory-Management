"""Inventory API application package."""
