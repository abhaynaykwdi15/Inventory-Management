"""Inventory API tests."""
